import { Component } from '@angular/core';
import { Produto } from '../model/produto';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-vitrine',
  imports: [CommonModule],
  templateUrl: './vitrine.html',
  styleUrl: './vitrine.css',
})
export class Vitrine {
  mensagem: string = "";
  lista: Produto[] = [
  {
    "codigo": 1,
    "nome": "Furadeira de Impacto 750W",
    "descritivo": "Furadeira elétrica com função impacto, ideal para concreto, madeira e metal.",
    "valor": 349.9,
    "promo": 299.9,
    "quantidade": 15
  },
  {
    "codigo": 2,
    "nome": "Parafusadeira Sem Fio 12V",
    "descritivo": "Parafusadeira compacta com bateria recarregável e controle de torque.",
    "valor": 259.9,
    "promo": 219.9,
    "quantidade": 0
  },
  {
    "codigo": 3,
    "nome": "Jogo de Chaves de Fenda 6 Peças",
    "descritivo": "Conjunto de chaves de fenda e philips com cabo ergonômico.",
    "valor": 89.9,
    "promo": 69.9,
    "quantidade": 40
  },
  {
    "codigo": 4,
    "nome": "Martelo Unha 27mm",
    "descritivo": "Martelo com cabeça em aço forjado e cabo emborrachado antiderrapante.",
    "valor": 59.9,
    "promo": 49.9,
    "quantidade": 35
  },
  {
    "codigo": 5,
    "nome": "Serra Tico-Tico 650W",
    "descritivo": "Serra elétrica para cortes curvos e retos em madeira, plástico e metal.",
    "valor": 329.9,
    "promo": 279.9,
    "quantidade": 0
  },
  {
    "codigo": 6,
    "nome": "Trena 5m com Trava",
    "descritivo": "Trena resistente com fita metálica e sistema de trava automática.",
    "valor": 29.9,
    "promo": 19.9,
    "quantidade": 60
  },
  {
    "codigo": 7,
    "nome": "Alicate Universal 8\"",
    "descritivo": "Alicate multifuncional em aço carbono com cabo isolado.",
    "valor": 49.9,
    "promo": 39.9,
    "quantidade": 45
  },
  {
    "codigo": 8,
    "nome": "Esmerilhadeira Angular 850W",
    "descritivo": "Ferramenta elétrica para corte e desbaste em metais e concreto.",
    "valor": 379.9,
    "promo": 329.9,
    "quantidade": 10
  },
  {
    "codigo": 9,
    "nome": "Nível de Alumínio 40cm",
    "descritivo": "Nível com estrutura em alumínio leve e bolhas de alta precisão.",
    "valor": 39.9,
    "promo": 29.9,
    "quantidade": 0
  },
  {
    "codigo": 10,
    "nome": "Jogo de Soquetes 40 Peças",
    "descritivo": "Kit completo de soquetes com catraca e maleta organizadora.",
    "valor": 199.9,
    "promo": 159.9,
    "quantidade": 18
  }
];



}
